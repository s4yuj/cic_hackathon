import json
import boto3
import os

s3 = boto3.client("s3")
BUCKET = os.environ.get("POSTS_BUCKET", "all-posts")  # fallback for local testing

def stream_to_string(streaming_body):
    """Convert S3 StreamingBody to string."""
    return streaming_body.read().decode("utf-8")

def lambda_handler(event, context):
    try:
        # --- Query params ---
        qs = event.get("queryStringParameters") or {}
        limit = int(qs.get("limit", 5))
        limit = min(limit, 50)
        continuation_token = qs.get("continuationToken")

        # --- List S3 objects ---
        list_params = {
        "Bucket": BUCKET,
        "MaxKeys": limit
        }

        if continuation_token:
            list_params["ContinuationToken"] = continuation_token

        list_resp = s3.list_objects_v2(**list_params)
        objects = sorted(list_resp.get("Contents", []), key=lambda o: o["LastModified"], reverse=True)

        posts = []
        for obj in objects:
            key = obj["Key"]
            get_resp = s3.get_object(Bucket=BUCKET, Key=key)
            body_str = stream_to_string(get_resp["Body"])
            post_json = json.loads(body_str)
            posts.append(post_json)

        response_body = {
            "posts": posts,
            "nextContinuationToken": list_resp.get("NextContinuationToken")
        }

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(response_body)
        }

    except Exception as e:
        print("ERROR:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }



