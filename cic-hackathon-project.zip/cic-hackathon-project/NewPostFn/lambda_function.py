import json
import boto3
import os
import logging
import time
import uuid

# Initialize AWS Clients
s3_client = boto3.client("s3")
bedrock = boto3.client("bedrock-runtime", region_name="us-west-2")

# Constants
BUCKET_NAME = os.environ.get("POSTS_BUCKET")
NOVA_MODEL_ID = "us.amazon.nova-pro-v1:0"

# Logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def get_prompt(post_content):
    return post_content


def extract_json_from_text(text):
    """
    Extracts a valid JSON object from Bedrock text output.
    """
    try:
        json_start = text.find("{")
        json_end = text.rfind("}") + 1
        json_str = text[json_start:json_end]
        return json.loads(json_str)
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"JSON extraction failed: {e}")
        raise


def call_bedrock_model(post_content):
    """
    Calls Bedrock model to generate LinkedIn-style post.
    """
    logger.info("Calling Bedrock model...")
    # system_prompt = [{
    #     "text": "You are a tool that helps users write LinkedIn posts. You write professional LinkedIn posts for students and faculty at the University of British Columbia, Vancouver."
    # }]
    system_prompt = [{
        "text": (
            "You generate satirical LinkedIn-style posts specifically for University of British Columbia (UBC) students. "
            "Take the user-provided seed text and turn the most mundane student moment into an overly inspirational, "
            "corporate-jargon-heavy, self-serious LinkedIn hustle story with UBC flavour. Include campus references naturally "
            "(Koerner Library, AMS Nest, Sauder, CPSC courses, Buchanan, rain, etc.). Keep the tone humorous but written earnestly. "

            "RESPONSE FORMAT: Return ONLY a single valid JSON object with exactly these keys:\n"
            "{\n"
            "  \"name\": string,    // A fictional, plausible UBC-student-like full name. Base lightly on the seed if possible.\n"
            "  \"post\": string,    // The full LinkedIn-parody story (80–200 words). Multi-paragraph allowed with \\n\\n.\n"
            "  \"seed\": string     // Echo the original seed text exactly.\n"
            "}\n"

            "RULES:\n"
            "1. Transform the seed into a ridiculous but polished LinkedIn-style reflection.\n"
            "2. Use corporate clichés, vague insights, and exaggerated leadership lessons.\n"
            "3. Use UBC-related details naturally; no real individuals or private data.\n"
            "4. No profanity.\n"
            "5. Output must be valid JSON and nothing else.\n"
            "6. Do not add any extra keys or commentary.\n"
            "7. Do not include examples in the output."
            "8. Add emojis strategically."
            "9. Do not overuse UBC-specific words."
            "10. Do not copy the examples exactly."
        )
    }]

    # user_prompt = {
    #     "role": "user",
    #     "content": [{"text": get_prompt(post_content)}]
    # }
    user_prompt = {
        "role": "user",
        "content": [{"text": get_prompt(post_content)}]
    }


    response = bedrock.converse(
        modelId=NOVA_MODEL_ID,
        messages=[user_prompt],
        system=system_prompt,
        inferenceConfig={"maxTokens": 512, "temperature": 0.8}
    )

    raw_output = response["output"]["message"]["content"][0]["text"]
    logger.info(f"Raw Bedrock output: {raw_output}")
    return extract_json_from_text(raw_output)


def save_post_to_s3(name, post):
    """
    Saves the generated LinkedOut post to S3 as JSON.
    """
    now_ms = int(time.time() * 1000)
    unique_id = str(uuid.uuid4())
    MAX_TS = 9999999999999
    rev_ts = MAX_TS - now_ms
    rev_str = str(rev_ts).zfill(13)

    key = f"{rev_str}_{unique_id}.json"

    payload = {
        "id": unique_id,
        "name": name,
        "post": post,
        "timestamp": int(time.time()),
    }

    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=key,
        Body=json.dumps(payload, indent=4),
        ContentType="application/json"
    )

    logger.info(f"✅ Post saved at s3://{BUCKET_NAME}/{key}")
    return payload




def lambda_handler(event, context):
    """
    AWS Lambda handler: receives user text, calls LLM, saves to S3, and returns JSON.
    """
    try:
        # Parse request body
        if "body" in event:
            body = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
        else:
            body = event

        post_content = body.get("post_content", "")
        if not post_content:
            return {"statusCode": 400, "body": json.dumps({"error": "post_content is required"})}

        logger.info(f"Processing new post: {post_content}")

        # 1️⃣ Generate the funny LinkedOut post
        generated_post = call_bedrock_model(post_content)
        name = generated_post.get("name", "Anonymous User")
        post = generated_post.get("post", post_content)

        # 2️⃣ Save post to S3
        saved_payload = save_post_to_s3(name, post)

        # 3️⃣ Return response to frontend
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "message": "Post generated successfully!",
                "data": saved_payload
            })
        }


    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }




