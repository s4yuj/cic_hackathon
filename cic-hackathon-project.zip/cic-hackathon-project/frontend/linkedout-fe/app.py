import streamlit as st
import json
import datetime
import requests
import base64
from streamlit_folium import st_folium
import folium

# ----------------------- CONFIG -----------------------
st.set_page_config(page_title="LinkedOut", page_icon="💼", layout="centered")

# Hide Streamlit chrome
st.markdown("""
<style>
header[data-testid="stHeader"] {display:none;}
footer{visibility:hidden;}
#MainMenu{visibility:hidden;}
</style>
""", unsafe_allow_html=True)

# ----------------------- BACKEND ENDPOINTS -----------------------
# Replace with real deployed URLs from your SAM outputs
POST_URL = "https://tskbwhbod2.execute-api.us-west-2.amazonaws.com/Prod/post"
FEED_URL = "https://tskbwhbod2.execute-api.us-west-2.amazonaws.com/Prod/feed"

# ----------------------- LOAD CSS -----------------------
with open("components/linkedout.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# ----------------------- SESSION STATE -----------------------
st.session_state.setdefault("page", "feed")
st.session_state.setdefault("feed", [])
st.session_state.setdefault("next_token", None)

# ----------------------- HELPERS -----------------------
def get_location_from_ip():
    """Approximate user location (lat/lon) via IP."""
    try:
        ip = requests.get("https://api.ipify.org").text
        geo = requests.get(f"https://ipinfo.io/{ip}/json").json()
        lat, lon = map(float, geo["loc"].split(","))
        return lat, lon
    except Exception:
        return None, None

def call_new_post_fn(sentence, lat, lon):
    """Call backend NewPostFn Lambda via API Gateway."""
    payload = {"post_content": sentence, "lat": lat, "lon": lon}
    try:
        res = requests.post(POST_URL, json=payload)
        if res.status_code == 200:
            data = res.json()
            return data.get("data", {})
        else:
            st.error(f"⚠️ {res.status_code}: {res.text}")
            return None
    except Exception as e:
        st.error(f"❌ Network error: {e}")
        return None

def call_get_post_fn(limit=5, continuation_token=None):
    """Fetch posts from FeedManagerFn Lambda."""
    params = {"limit": limit}
    if continuation_token:
        params["continuationToken"] = continuation_token

    try:
        res = requests.get(FEED_URL, params=params)
        if res.status_code == 200:
            data = res.json()
            posts = data.get("posts", [])
            next_token = data.get("nextContinuationToken")
            return posts, next_token
        else:
            st.error(f"⚠️ {res.status_code}: {res.text}")
            return [], None
    except Exception as e:
        st.error(f"❌ Network error: {e}")
        return [], None

def b64(path):
    """Load local image and return base64 string for inline embedding."""
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()

# ----------------------- HEADER ICONS -----------------------
logo_b64 = b64("assets/linkedout-logo.png")
home_b64 = b64("assets/home.png")
map_b64  = b64("assets/map.png")

header_html = f"""
<div class="header">
  <div style="display:flex;align-items:center;gap:1rem;">
    <img src="data:image/png;base64,{logo_b64}" class="logo">
    <input type="text" class="search-bar" placeholder="🔍 Search (coming soon)" disabled>
  </div>
  <div class="icon-container">
    <form action="#" method="get">
      <button class="icon-btn" name="page" value="feed" type="submit">
        <img src="data:image/png;base64,{home_b64}" height="26">
      </button>
      <button class="icon-btn" name="page" value="map" type="submit">
        <img src="data:image/png;base64,{map_b64}" height="26">
      </button>
    </form>
  </div>
</div>
"""
st.markdown(header_html, unsafe_allow_html=True)

# ----------------------- PAGE NAVIGATION -----------------------
if "page" in st.query_params:
    st.session_state.page = st.query_params["page"]
    st.query_params.clear()
    st.rerun()

# ----------------------- FEED PAGE -----------------------
if st.session_state.page == "feed":
    st.markdown("## Make a Post")
    user_input = st.text_area("What's on your mind?", placeholder="Share your story...")

    if st.button("Post", use_container_width=True):
        if user_input.strip():
            lat, lon = get_location_from_ip()
            new_post = call_new_post_fn(user_input.strip(), lat, lon)
            if new_post:
                st.session_state.feed.insert(0, new_post)
                st.success(f"✅ Posted successfully as **{new_post.get('name', 'Anonymous User')}**!")
                st.rerun()
        else:
            st.warning("Please write something first.")

    st.markdown("---")

    # Load feed if empty
    if not st.session_state.feed:
        posts, next_token = call_get_post_fn(limit=5)
        st.session_state.feed = posts
        st.session_state.next_token = next_token

    # Render feed
    for post in st.session_state.feed:
        name = post.get("name", "Anonymous User")
        content = post.get("generated_post") or post.get("post") or "(no text)"
        ts = post.get("timestamp")
        loc = post.get("location", [49.26, -123.25])
        try:
            ts_fmt = datetime.datetime.fromtimestamp(int(ts)).strftime("%Y-%m-%d %H:%M:%S")
        except:
            ts_fmt = ts

        st.markdown(f"""
        <div class="post-card">
          <div style="font-weight:600;font-size:1.1rem;margin-bottom:0.4rem;">👤 {name}</div>
          <p>{content}</p>
          <hr>
          <small>📍 {loc[0]:.4f}, {loc[1]:.4f} · 🕒 {ts_fmt}</small>
        </div>
        """, unsafe_allow_html=True)

    if st.session_state.next_token:
        if st.button("Load More", use_container_width=True):
            new_posts, next_token = call_get_post_fn(limit=5, continuation_token=st.session_state.next_token)
            st.session_state.feed.extend(new_posts)
            st.session_state.next_token = next_token
            st.rerun()

# ----------------------- MAP PAGE -----------------------
elif st.session_state.page == "map":
    import streamlit.components.v1 as components

    st.markdown("""
    <style>
    .stApp {overflow: hidden !important;}
    iframe {border: none !important;}
    iframe[title="st.iframe"] {width: 100vw !important; max-width: 100vw !important;}
    div[data-testid="stVerticalBlock"] > div:has(iframe) {justify-content: flex-start !important;}
    .block-container {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
    }
    main {padding-left: 0 !important; padding-right: 0 !important;}
    </style>
    """, unsafe_allow_html=True)

    ubc_coords = [49.2606, -123.2460]
    m = folium.Map(location=ubc_coords, zoom_start=15, control_scale=True)

    for post in st.session_state.feed:
        content = post.get("generated_post") or post.get("post") or "(no text)"
        name = post.get("name", "Anonymous User")
        loc = post.get("location", [49.26, -123.25])
        popup_html = f"<b>{name}</b><br>{content}"
        folium.Marker(location=loc, popup=popup_html).add_to(m)

    st_folium(m, width=1920, height=707)

